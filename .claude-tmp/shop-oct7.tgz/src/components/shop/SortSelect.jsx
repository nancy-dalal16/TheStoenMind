"use client";

import { usePathname, useRouter } from "next/navigation";
import { useId, useTransition } from "react";
import Icon from "@/components/ui/Icon";
import { sortOptions } from "@/lib/shop/copy";

/** Native <select> (accessible, phone-friendly) dressed as a quiet text control. */
export default function SortSelect({ value = "featured" }) {
  const router = useRouter();
  const pathname = usePathname();
  const id = useId();
  const [pending, startTransition] = useTransition();

  const onChange = (event) => {
    const next = event.target.value;
    startTransition(() => {
      router.replace(next === "featured" ? pathname : `${pathname}?sort=${next}`, { scroll: false });
    });
  };

  return (
    <div className={`flex items-center gap-2 transition-opacity ${pending ? "opacity-50" : ""}`}>
      <label htmlFor={id} className="font-sans text-xs tracking-[0.08em] text-fg-muted">
        Sort
      </label>
      <div className="relative">
        <select
          id={id}
          value={value}
          onChange={onChange}
          className="shop-select cursor-pointer appearance-none bg-transparent py-1 pr-6 font-sans text-sm tracking-[0.02em] text-fg"
        >
          {sortOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <Icon
          name="caret-down"
          width={18}
          height={18}
          className="pointer-events-none absolute top-1/2 right-0 -translate-y-1/2 text-fg-muted"
        />
      </div>
    </div>
  );
}
